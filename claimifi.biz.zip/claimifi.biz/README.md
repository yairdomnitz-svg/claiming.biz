# Claimifi.biz — Historical Fact-Checker

**Live domain:** claimifi.biz

A modern AI-powered website that fact-checks historical claims made in YouTube videos.  
Focused on global and ancient history. Powered by Grok (xAI).

## Project Structure

```
claimifi.biz/
├── index.html              ← Frontend
├── README.md
└── backend/
    ├── main.py             ← FastAPI (serves frontend + API)
    ├── requirements.txt
    └── .env.example
```

## How to make claimifi.biz fully live

### Option A – Easiest full site (Recommended): Railway

1. Create a free account at https://railway.app
2. Create a new project → “Deploy from GitHub” (upload this folder to a GitHub repo first) **or** use Railway’s CLI / empty service and upload files.
3. In the service settings:
   - Root directory: `backend` (or the folder containing main.py)
   - Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - Add environment variable: `XAI_API_KEY` = your key from https://console.x.ai
4. Once deployed, Railway gives you a public URL (e.g. something.up.railway.app).
5. In Railway → Settings → Domains → Add custom domain: **claimifi.biz**
6. Go to your domain registrar (where you bought claimifi.biz) and add the CNAME / DNS records that Railway shows you.
7. Wait a few minutes for DNS to propagate.

After that, opening **https://claimifi.biz** will run the full site (frontend + real Grok analysis).

### Option B – Frontend only (fast demo) on Netlify

1. Go to https://app.netlify.com/drop
2. Drag the whole `claimifi.biz` folder (or just index.html)
3. Netlify gives you a temporary link.
4. In Netlify → Domain settings → Add custom domain → claimifi.biz
5. Update DNS at your registrar.

Note: This only gives the demo mode. Real YouTube transcript + Grok analysis needs the backend (Option A).

### Option C – Render

Similar to Railway: https://render.com → New Web Service → connect repo → set build/start commands and `XAI_API_KEY`.

## Local testing

```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
export XAI_API_KEY="your-key"
uvicorn main:app --reload --port 8000
```

Open http://localhost:8000

## Important

- You need an xAI API key from https://console.x.ai for real analysis.
- Videos must have captions/transcripts available.
- The free tier of Railway/Render is usually enough for light personal / early public use.
- Always keep your `XAI_API_KEY` secret (never put it in the frontend).

## Trusted sources (hard-coded)

historians.org, oah.org, history.ac.uk, iamhist.net, jstor.org, muse.jhu.edu,  
archives.gov, docsteach.org, loc.gov, britishpathe.com, aparchive.com,  
americanarchive.org, iwm.org.uk, bfi.org.uk, dp.la, archive.org,  
academic.oup.com, cambridge.org, hup.harvard.edu, yalebooks.yale.edu,  
press.princeton.edu, press.uchicago.edu, ucpress.edu, cup.columbia.edu,  
taylorandfrancis.com, routledge.com, brill.com, onlinelibrary.wiley.com,  
iupress.org, factcheck.org, politifact.com, snopes.com
